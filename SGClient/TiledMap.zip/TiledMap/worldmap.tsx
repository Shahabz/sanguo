<?xml version="1.0" encoding="UTF-8"?>
<tileset name="worldmap" tilewidth="256" tileheight="128" spacing="2" margin="2" tilecount="21" columns="3">
 <image source="worldmap.png" width="1024" height="1024"/>
 <terraintypes>
  <terrain name="grass" tile="0"/>
  <terrain name="land" tile="0"/>
 </terraintypes>
 <tile id="0" terrain="1,1,1,0"/>
 <tile id="1" terrain="0,0,0,0"/>
 <tile id="2" terrain="0,1,0,0"/>
 <tile id="3" terrain="1,1,1,1"/>
 <tile id="4" terrain="0,0,1,0"/>
 <tile id="5" terrain="1,0,1,0"/>
 <tile id="6" terrain="1,0,0,0"/>
 <tile id="7" terrain="0,1,0,1"/>
 <tile id="8" terrain="0,0,0,1"/>
 <tile id="9" terrain="1,1,0,0"/>
 <tile id="10" terrain="1,0,0,1"/>
 <tile id="11" terrain="0,1,1,0"/>
 <tile id="12" terrain="0,1,1,1"/>
 <tile id="13" terrain="0,0,1,1"/>
 <tile id="14" terrain="1,0,1,1"/>
 <tile id="15" terrain="1,1,0,1"/>
 <tile id="16" terrain="0,0,0,0"/>
 <tile id="17" terrain="0,0,0,0"/>
 <tile id="18" terrain="0,0,0,0"/>
 <tile id="19" terrain="0,0,0,0"/>
 <tile id="20" terrain="0,0,0,0"/>
</tileset>
