<?xml version="1.0" encoding="UTF-8"?>
<tileset name="worldmap_road" tilewidth="256" tileheight="128" tilecount="8" columns="2">
 <image source="worldmap_road.png" width="512" height="512"/>
</tileset>
